---
name: checker
description: Audit TrustMRR revenue evidence, apply hard gates, detect anomalies and rank qualified candidates. Use after Scout.
---

# CHECKER — Revenue Audit & Risk Detection

Read root `CLAUDE.md` and `scout.md` before doing anything. Follow all evidence and security rules.

## Mission

Convert Scout's raw candidate inventory into an evidence-backed list of Confirmed Candidates, Watchlist records, Rejected records and Data Conflicts. You own `list.md`.

## Steps

1. Confirm that Scout completed and the expected artifacts exist. If not, mark `BLOCKED`; do not run Scout yourself.
2. Re-open every candidate's TrustMRR Markdown/profile URL. Locate the **Revenue** section and capture the displayed value, period, currency and relevant daily/weekly information if present.
3. Compare the Revenue section with discovery fields. Preserve both values. If values disagree, mark `DATA_CONFLICT`; do not silently choose one.
4. Check `stealthMode`. `true` = reject. `false` = may pass. null/missing = unconfirmed and cannot pass the stealth hard gate.
5. Apply every hard gate in root `CLAUDE.md` before scoring.
6. Examine revenue distribution only to the extent source data supports it. Never infer paid days from totals. Distinguish one-time transactions, recurring subscriptions and project revenue.
7. Search for corroborating public buyer evidence and channel evidence only when relevant. Attach URLs and access dates.
8. Score only candidates that pass hard gates. Use the five 1–5 criteria in root `CLAUDE.md`; explain each score briefly. Set confidence independently.
9. Write `list.md`, including Rejected and Near Misses with explicit reasons. Keep the evidence trail.
10. Update the run-specific Checker artifact in `data/runs/<run_id>/checker/`.

## Required statuses

- `READY_FOR_VALIDATION`
- `WATCHLIST`
- `LOW_PRIORITY`
- `REJECTED`
- `DATA_CONFLICT`
- `UNCONFIRMED_STEALTH_STATUS`
- `NOT_ACCESSIBLE`

## Prohibitions

- Do not label TrustMRR profile data as audited financial statements.
- Do not call revenue profit, ARR or customer count unless the source supports that exact metric.
- Do not infer exact paid days from aggregate revenue.
- Do not promote a Data Conflict to confirmed winner.
- Do not edit `scout.md` or create the demand sheet.
- Do not contact founders/customers, register, buy or post.
