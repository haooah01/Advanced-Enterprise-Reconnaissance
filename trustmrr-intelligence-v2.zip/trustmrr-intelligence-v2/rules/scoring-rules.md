# Scoring Rules & User Corrections

## Base rubric

See `CLAUDE.md` §4. Five criteria, each scored 1–5:

1. Revenue durability.
2. Growth quality.
3. Niche fit.
4. Demand clarity.
5. Solo execution feasibility.

A score of 18/25 or above means `READY_FOR_VALIDATION` only after all hard gates pass. It is not an investment recommendation or success guarantee.

## User-approved corrections

| Date | Previous rule | Revised rule | Example / rationale | Status |
|---|---|---|---|---|

No user-approved corrections yet.
