# Permanent Denylist

> Only add an entry when the user explicitly rejects a candidate or explicitly asks to blacklist it.

| Date | Startup slug | Name | User's rejection reason | Original wording |
|---|---|---|---|---|

No entries yet.
