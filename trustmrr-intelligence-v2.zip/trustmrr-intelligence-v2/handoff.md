# Viktor — Weekly Research Handoff

## Purpose

Run the weekly public-source research tasks that do not require access to the user's local laptop. This file is a handoff specification, not proof that a Slack message or scheduled task has been created.

## Required synced inputs

- Current `CLAUDE.md` user configuration (exclude secrets).
- `list.md` and `data/seen-ledger.csv`.
- `rules/denylist.md` and `rules/scoring-rules.md`.
- Relevant prior run summaries and demand sheets.

Do not assume local files are accessible. Confirm that the approved shared folder or Slack attachment is available before starting.

## Weekly tasks — Monday 09:00 Asia/Ho_Chi_Minh

1. Read the latest approved rules and existing ledger.
2. Discover newly listed/updated candidates from allowed public TrustMRR sources.
3. Exclude candidates already in the seen ledger or denylist unless evidence changed materially.
4. Preserve all source URLs, timestamps, source labels and discrepancies.
5. Apply hard gates before scoring.
6. Prepare a weekly summary and a demand brief for the best newly qualified candidate.
7. Return outputs to the approved shared destination.

## Prohibited actions

- No contacting founders, customers or partners.
- No account registration, purchases, subscriptions, form submissions or public posts.
- No accessing local laptop files unless they have been explicitly synced and permission is granted.
- No secrets, API keys, cookies or tokens in reports or Slack.
- No bypassing paywalls, authentication, rate limits or service terms.

## Return format

- Run ID and completion status.
- New candidates and evidence URLs.
- Rejected candidates with reasons.
- Revenue conflicts and unavailable data.
- Ranked newly qualified candidates.
- Link to the best new demand brief.
- Questions requiring the user's decision.
