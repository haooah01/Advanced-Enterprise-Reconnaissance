# TrustMRR Intelligence V2 — Starter Kit

## Included

- `CLAUDE.md`: master instructions, intake, evidence policy, revenue hard gates, scoring, orchestration, persistence, schedule boundaries and acceptance checklist.
- `.claude/agents/`: role instructions for Scout, Checker and Opportunity Architect.
- `scout.md`, `list.md`, `morning.md`, `handoff.md`: initial output files.
- `rules/`: denylist and scoring-rule persistence.
- `data/`: raw evidence and run storage.
- `sheets/` and `templates/`: demand-sheet structure.

## First use

1. Extract this folder into your project workspace.
2. Open the folder in Claude Code.
3. Open `CLAUDE.md` and complete the `USER CONFIGURATION` section, or answer the four intake questions when Claude asks.
4. Ask Claude Code to perform the `FIRST RUN PROCEDURE` in `CLAUDE.md`.
5. Review the three-candidate Scout test before authorizing a full run.

## Important limits

This kit does not install Claude Code, configure permissions, create local scheduled tasks, or connect Viktor/Slack. The schedule in `CLAUDE.md` is a target plan only. Configure and verify those separately in the actual execution environment. Do not grant broad command permissions merely to make the run unattended.
