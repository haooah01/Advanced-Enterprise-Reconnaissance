# Data directory

- `raw/`: immutable source captures; never overwrite an earlier capture.
- `runs/`: run-specific outputs, evidence logs, status and rejection details.
- `seen-ledger.csv`: initialize from prior results and maintain across weekly runs.

Recommended ledger header:

```csv
first_seen_at,last_seen_at,slug,domain,name,last_status,best_score,trustmrr_url,notes
```
