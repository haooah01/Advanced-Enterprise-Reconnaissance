# Morning Brief

> Status: NOT_STARTED  
> Run ID: NOT_STARTED  
> Deadline: 07:30 Asia/Ho_Chi_Minh

## The night in 3 lines

- Not run.
- No revenue figures verified.
- No winner selected.

## Ranked winners

No confirmed winners.

## Fraud / risk table (maximum 5)

No run completed.

## Best opportunity

Not available.

## Waiting for user

Complete the four intake questions in `CLAUDE.md` before the first run.
