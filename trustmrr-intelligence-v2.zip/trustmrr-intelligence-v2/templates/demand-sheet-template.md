# Demand Sheet — [Startup / Opportunity]

## 1. Business snapshot
- Name / slug:
- Website:
- TrustMRR profile:
- Revenue 30d (Revenue section):
- Payment provider:
- Evidence label:
- Confidence:
- Snapshot date:

## 2. Buyer problem
- Buyer segment:
- Problem in buyer language:
- Repeated evidence:
- Sources and access dates:

## 3. Current offer & monetization
- Product / outcome:
- Listed price and billing cadence:
- Payment method (only if sourced):
- What is known vs unknown:

## 4. Distribution
| Channel | Evidence label | Source URL | Access date | Confidence |
|---|---|---|---|---|

## 5. Why the mechanism may work
- Observed facts:
- Hypotheses/inferences:

## 6. Three independent variants
1. Different customer segment:
2. Different channel:
3. Different offer/delivery mechanism:

## 7. Solo MVP
- Smallest testable version:
- Skills required:
- Missing capabilities/dependencies:
- Costs to verify:

## 8. Validation plan
- Hypothesis:
- Test:
- Observable metric:
- Continue threshold:
- Stop threshold:

## 9. TẠI SAO ĐIỀU NÀY CÓ THỂ THẤT BẠI
1.
2.
3.
