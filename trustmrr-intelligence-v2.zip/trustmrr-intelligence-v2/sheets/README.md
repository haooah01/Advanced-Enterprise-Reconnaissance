# Demand sheets

The Opportunity Architect writes one file per selected business:

`demand-<slug>.md`

Use the section contract in `CLAUDE.md` §6. Do not copy code, branding, copyrighted text, images or proprietary implementation.
